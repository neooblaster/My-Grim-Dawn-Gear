<?php

	const VERSION = '0.1.7.0';

?>