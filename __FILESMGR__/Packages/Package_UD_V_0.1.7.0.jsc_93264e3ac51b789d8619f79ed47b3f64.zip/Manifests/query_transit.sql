-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Ven 19 Août 2016 à 21:42
-- Version du serveur :  5.5.44-0+deb8u1
-- Version de PHP :  5.6.24-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `MY-GRIMDAWN-GEAR`
--

--
-- Contenu de la table `ITEMS_TAGS_NAMES`
--

INSERT INTO `ITEMS_TAGS_NAMES` (`ID`, `LANG`, `TAG_NAME`, `NAME`, `MD5`) VALUES
(null, 'en-EN', 'tagShoulderC001xE', 'Empowered Razorback''s Spined Mantle', '5f7a6ebeaa3030a9f7e3a2b5863f8271'),
(null, 'en-EN', 'tagShoulderC002xE', 'Empowered Astral Mantle', '5c38ffe56343e47307954574d89f0557'),
(null, 'en-EN', 'tagShoulderC003xE', 'Empowered Warlord''s Spaulders', '405e414a15eff3b829ba2d68ab8afd4f'),
(null, 'en-EN', 'tagShoulderC004xE', 'Empowered Guardsman''s Spaulders', '2388318cbe381b847c17cea57e632392'),
(null, 'en-EN', 'tagShoulderC005xE', 'Empowered Grenadier Shoulderguard', '8dca22df8f20276d4e833e9631b48e41'),
(null, 'en-EN', 'tagShoulderC006xE', 'Empowered Mantle of the Weeping Eye', '324bb609b3d294caa648fe1fe7cf893e'),
(null, 'en-EN', 'tagShoulderC010xE', 'Empowered Shoulderguards of Perdition', 'c34b06330411944ee8b97bd00cbdc92f'),
(null, 'en-EN', 'tagShoulderC015xE', 'Empowered Brimstone Shoulderguard', 'ace372f459913feb5a98424394fb98f0'),
(null, 'en-EN', 'tagTorsoC002xE', 'Empowered Nighthunter''s Chestguard', '7fd6d3df0f003f60bc1f6879bd5c8a99'),
(null, 'en-EN', 'tagTorsoC003xE', 'Empowered Gunslinger''s Jacket', 'df3b5a8d0f2f18bf6b4812059d8b7866'),
(null, 'en-EN', 'tagTorsoC004xE', 'Empowered Malduin''s Cloth', '59eb70e49169e7f5165b33415ab80705'),
(null, 'en-EN', 'tagTorsoC005xE', 'Empowered Doomforged Breastplate', '76705e79fa3719a4a9707efaefb2c4f9'),
(null, 'en-EN', 'tagTorsoC006xE', 'Empowered Guardsman''s Breastplate', '683703b1bc236b546e537d6aad4e9603'),
(null, 'en-EN', 'tagTorsoC008xE', 'Empowered Bloodreaper''s Coat', '60b4127a5e39898ace9b6b96bf869e11'),
(null, 'en-EN', 'tagTorsoC009xE', 'Empowered Fanatic''s Overcoat', 'ebf0966c915b9822c82b6c7ee3aada7e'),
(null, 'en-EN', 'tagTorsoC010xE', 'Empowered Fused Carapace Armor', '7f4d3221c28ce939d46ab87f37b10ada'),
(null, 'en-EN', 'tagTorsoC011xE', 'Empowered Skinflayer Raiment', '8f26eb876a1bf58d0ddcfabb73cc1cb1'),
(null, 'en-EN', 'tagTorsoC017xE', 'Empowered Herald''s Jacket', '4a5c68d100703f457b23736383424e55'),
(null, 'en-EN', 'tagTorsoC018xE', 'Empowered Chestguard of Perdition', 'f9b41b9ebe15ec7baade05b7857f0e95'),
(null, 'en-EN', 'tagTorsoC022xE', 'Empowered Zolhan''s Battle Plate', '1e29353853459a67f50d89fbcc5bf8f2'),
(null, 'en-EN', 'tagTorsoC023xE', 'Empowered Miasma Robes', 'b39aeaa1ba95be1358743bc1d56d31dd'),
(null, 'en-EN', 'tagTorsoC025xE', 'Empowered Wildcaller''s Skins', 'a0d1cc08986c4c2c34559eae2e1a9128'),
(null, 'en-EN', 'tagHandsC001xE', 'Empowered Shadow''s Grasp', 'cd73fd9cfe092b4eab7eb83edbe594ec'),
(null, 'en-EN', 'tagHandsC002xE', 'Empowered Zealot''s Gauntlets', 'd2a9c386f3b4fbefdb32ef7a57c29add'),
(null, 'en-EN', 'tagHandsC003xE', 'Empowered Bladedancer''s Handguards', '1b52b28640ae6e8dd037eefc46288263'),
(null, 'en-EN', 'tagHandsC004xE', 'Empowered Spellbinder''s Grip', 'ca07753a8371fc07cc708a6490daf5ec'),
(null, 'en-EN', 'tagHandsC005xE', 'Empowered Marauder''s Gloves', '351b5b7a43e9b0403888133ae6502d6c'),
(null, 'en-EN', 'tagHandsC006xE', 'Empowered Soul''s Touch', '1dbcfa271ed73f6c0801768fa5fa4f39'),
(null, 'en-EN', 'tagHandsC007xE', 'Empowered Inscribed Bracers', '5deeabf656c46194115463b9976772a8'),
(null, 'en-EN', 'tagHandsC008xE', 'Empowered Brawler''s Gloves', '19711b117473b24c24177c2b69e513ad'),
(null, 'en-EN', 'tagHandsC013xE', 'Empowered Apothecary''s Touch', 'da5e345508a108fed828ccbab0a49c9a'),
(null, 'en-EN', 'tagHandsC014xE', 'Empowered Handguards of Perdition', 'b9eeabfb639f52b61bdff3dcfeae0a55'),
(null, 'en-EN', 'tagHandsC016xE', 'Empowered Embergrip Handguards', 'f71f5c6f175d7729ea32babe4d092e4b'),
(null, 'en-EN', 'tagHandsC017xE', 'Empowered Quickdraw Gloves', '14568cc26b948d01776648d26292521f'),
(null, 'en-EN', 'tagHandsC019xE', 'Empowered Thundertouch Bracers', '516abc98f58684a7a537aa49cc65bd34'),
(null, 'en-EN', 'tagLegsC001xE', 'Empowered Mistwalker Leggings', '54f290ea4452dc6d3426d6ba244d3b99'),
(null, 'en-EN', 'tagLegsC002xE', 'Empowered Hermit''s Legguards', 'aa4f8552ea6fcc20a4a6546d35e53df6'),
(null, 'en-EN', 'tagLegsC003xE', 'Empowered Swampdweller''s Legguards', '9f8f5843ae9b0f83bf0d077ce95d2ff4'),
(null, 'en-EN', 'tagLegsC005xE', 'Empowered Soiled Trousers', '71d3a0688948583fc138d03763cc3ab6'),
(null, 'en-EN', 'tagLegsC006xE', 'Empowered Slithscale Legwraps', '32a6c4c539ee47910f9734b5d9f92e3b'),
(null, 'en-EN', 'tagLegsC007xE', 'Empowered Templar''s Leg Armor', '617a380e6a97981ed93af0aa62d3b14b'),
(null, 'en-EN', 'tagLegsC008xE', 'Empowered Legplates of Valor', 'aa3dac41791fc648df3f8a6fcb962733'),
(null, 'en-EN', 'tagFeetC001xE', 'Empowered Molten Walkers', '93a725d445062fbac3ad20a7613e260b'),
(null, 'en-EN', 'tagFeetC002xE', 'Empowered Windborne Greaves', '88cd1d04719ba5d4e3c02bbf48320a94'),
(null, 'en-EN', 'tagFeetC003xE', 'Empowered Boots of Unseeing Swiftness', '43d604b524013dcc59240435d5e78871'),
(null, 'en-EN', 'tagFeetC004xE', 'Empowered Stonewrought Groundbreakers', '253947bedf120217c09e721e95c3dc23'),
(null, 'en-EN', 'tagFeetC006xE', 'Empowered Bloodhound Greaves', 'efe322d28daff90ebe2b18a0c51b16a2'),
(null, 'en-EN', 'tagFeetC007xE', 'Empowered The Final March', '3e681e0576c93cc22aeab48a47018e32'),
(null, 'en-EN', 'tagFeetC008xE', 'Empowered Rifthound Leather Boots', 'c1254d897a3999438710cba069c2655d'),
(null, 'en-EN', 'tagFeetC009', 'Empowered Dreadnought Footpads', '6bb4ac72e9f3517db81e46dc1617cc6b');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
