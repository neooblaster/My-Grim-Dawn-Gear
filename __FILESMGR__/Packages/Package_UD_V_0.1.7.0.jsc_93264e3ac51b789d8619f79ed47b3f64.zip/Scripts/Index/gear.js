function gear(){
	var self = this;
	
	self.qualities = ['unset', 'common', 'magic', 'rare', 'elite', 'legendary'];
	self.qualities_name = ['Unqualified', 'Common', 'Magic', 'Rare', 'Epic', 'Legendary'];
	
	self.load = function(){
		return {
			build: function(){
				var to_load = document.querySelector('#build_id');
		
				if(to_load !== null){
					var xQuery = new xhrQuery();
						xQuery.target('/XHR/Index/load_build.php');
						xQuery.inputs(to_load);
						xQuery.callbacks(
							function(e){
								try {
									e = JSON.parse(e);
									
									for(var slot in e){
										self.load().slot(slot, e[slot]);
									}
									
								} catch (err){
									console.log("can not parse data");
								}
							}
						);
						xQuery.send();
				}
			},
			
			slot: function(slot, item_id){
				var xQuery = new xhrQuery();
					xQuery.target('/XHR/Index/load_slot.php');
					xQuery.values('item_id='+item_id);
					xQuery.callbacks(
						function(e){
							if(e !== ''){
								try {
									e = JSON.parse(e);
									
									var input_selector = slot.toLowerCase();
									var host_selector = slot.toLowerCase();
									var idx = host_selector.lastIndexOf('_');
										host_selector = host_selector.substr(0, idx);
									
									var host = document.querySelector('.'+host_selector);
										host.classList.add('quality_'+self.qualities[e.REL_QUALITY]);
										host.setAttribute('data-quality', self.qualities[e.REL_QUALITY]);
									
									var item = document.createElement('img');
										item.src = "/Images/Items/"+e.TAG_ITEM+'.png';
										item.setAttribute('data-item-id', item_id);
										item.setAttribute('data-quality', self.qualities[e.REL_QUALITY]);
										item.setAttribute('data-attachment', e.SLOT_ATTACHMENT);
										item.classList.add('size'+e.WIDTH+'x'+e.HEIGHT);
										
										host.appendChild(item);
									
									var input = document.querySelector('#input_'+input_selector);
										input.value = item_id;
								}catch (e){
									console.error("Can not parse data");
								}
							}
						}
					);
					xQuery.send();
			}
		};
	};
	
	self.save = function(){
		
		new xhrQuery().target('/XHR/Index/is_allow.php').callbacks(
			function(a){
				try {
					a = JSON.parse(a);
					
					if(a){
						var xQuery = new xhrQuery();
							xQuery.target('/XHR/Index/build_manager.php');
						
							for(var i = 0; i < document.forms.gear_form.elements.length; i++){
								xQuery.inputs(document.forms.gear_form.elements[i]);
							}
						
							xQuery.callbacks(
								function(e){
									try {
										e = JSON.parse(e);
										
										if(e.OPERATION === 'INSERT'){
											prompt('Find below your unique link to share it.', document.location.hostname+'/build/'+e.BUILD_CODE);
											history.replaceState("", "", "/build/"+e.BUILD_CODE);
											document.location.reload();
										}
										
									} catch(err){
										console.error("can not parse data", err, e);
									}
								}
							);
							
							xQuery.send();
					}
				} catch(arr){
					console.log("Can not parse data"/*, a*/);
				}
			}
		).send();
		
		

	};
	
	self.calc = function(){
		
	};
	
	self.slots = function(item){
		if(item !== undefined){
			var item_type = item.getAttribute('data-item-type');
		}
		
		return {
			drop: function(slot, e){
				var img = document.createElement('template');
					img.innerHTML = e.dataTransfer.getData('text/html');
					img = img.content.firstChild;
				
				var item_id = img.getAttribute('data-item-id');
				var item_attachment = img.getAttribute('data-attachment');
				
				slot.innerHTML = "";
				slot.classList.remove('quality_'+slot.getAttribute('data-quality'));
				slot.setAttribute('data-quality', img.getAttribute('data-quality'));
				slot.classList.add('quality_'+img.getAttribute('data-quality'));
				
				slot.appendChild(img);
				
				var slot_name;
				var slot_name_pattern = /^slot_/gi;
				
				for(var c = 0; c < slot.classList.length; c++){
					
					if(slot_name_pattern.test(slot.classList[c])){
						slot_name = slot.classList[c];
						break;
					}
				}
				
				var input_data = document.querySelector('#input_'+slot_name+'_'+item_attachment);
					input_data.value = item_id;
			},
			
			clear: function(){console.log('clear');},
			
			show: function(){
				var slots = document.querySelectorAll('.gear_panel_build_items_slot');
				
				for(var i = 0; i < slots.length; i++){
					var slot = slots[i];
					
					if(slot.getAttribute('hidden') === 'true'){
						continue;
					};
					
					var accept_item = slots[i].getAttribute('data-accept-item');
						accept_item = accept_item.split(',');
						
					var accepted = accept_item.lastIndexOf(item_type);
					
					if(accepted >= 0){
						slot.classList.add('droppable');
						
						slot.ondrop = function(evt){gear().slots().drop(this, evt);}.bind(slot);
						slot.ondragover = function(){return false;};
						slot.ondragenter = function(){self.slots().overlay(this).on();}.bind(slot);
						slot.ondragleave = function(){self.slots().overlay(this).off();}.bind(slot);
					} else {
						slot.classList.remove('droppable');
						
						slot.ondrop = "";
						slot.ondragover = "";
						slot.ondragenter = "";
						slot.ondragleave = "";
					} 
				}
			},
			
			hide: function(){
				var slots = document.querySelectorAll('.gear_panel_build_items_slot');
				
				for(var i = 0; i < slots.length; i++){
					var slot = slots[i];
					
					slot.classList.remove('droppable');
					slot.classList.remove('dropover');
					
					slot.ondrop = "";
					slot.ondragover = "";
					slot.ondragenter = "";
					slot.ondragleave = "";
				}
			},
			
			overlay: function(slot){
				return {
					on: function(){
						slot.classList.add('dropover');
					},
					
					off: function(){
						slot.classList.remove('dropover');
					}
				};
			}
		};
	};
	
	self.synchronize = function(src, target){
		document.querySelector('#'+target).value = src.value;
	};
	
	self.sign = function(){
		var xQuery = new xhrQuery();
		xQuery.target('/XHR/Index/sign.php');
		xQuery.values(
			"id="+document.querySelector('#build_id').value,
			"password="+prompt("Type your password")
		);
		xQuery.callbacks(
			function(e){
				try {
					e = JSON.parse(e);
					
					if(e.allow){
						var submit_input = document.createElement('input');
							submit_input.setAttribute('type', 'submit');
							submit_input.value = "Save";
							submit_input.title = "Update your gear";
						
						var sign_button = document.querySelector('#sign_button');
						
						sign_button.parentNode.replaceChild(submit_input, sign_button);
					} else {
						alert('Wrong Password. Try Again');
					}
				} catch (err){
					console.log("Can not parse data");
				}
			}
		);
		xQuery.send();
	};
	
	return self;
}


document.onreadystatechange = function(){
	if(document.readyState === 'complete'){
		gear().load().build();
	}
};