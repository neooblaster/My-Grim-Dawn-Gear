<?php

	/** Indique que le volet des attributs est fermé (stats_fold) **/
	//$vars['STATS_FOLD'] = "stats_fold";

	/** Indique que le volet inventaire est fermé (inventory_fold) **/
	//$vars['INVENTORY_FOLD'] = "inventory_fold";

	/** > Chargement des jeux de donnée **/
		$vars['ITEMS_FAMILIES'] = load_items_families();
		//$vars['ITEMS_QUALITIES'] = load_items_qualities();
		$vars['ITEMS_TYPES'] = load_items_types();
		//$vars['ITEMS'] = load_items();


?>