<?php

	const VERSION = '0.1.8.0';

?>