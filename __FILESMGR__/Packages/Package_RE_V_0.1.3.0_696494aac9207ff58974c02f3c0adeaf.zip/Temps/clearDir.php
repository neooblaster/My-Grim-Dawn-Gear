<?php
// Supprimer un dossier et son contenu
function clearDir($dossier) {
    $ouverture=@opendir($dossier);
    if (!$ouverture) return;
    while($fichier=readdir($ouverture)) {
        if ($fichier == '.' || $fichier == '..') continue;
            if (is_dir($dossier."/".$fichier)) {
                $r=clearDir($dossier."/".$fichier);
                if (!$r) return false;
            }
            else {
                $r=@unlink($dossier."/".$fichier);
                if (!$r) return false;
            }
    }
	closedir($ouverture);
	$r=@rmdir($dossier);
	if (!$r) return false;
		 return true;
}
?>