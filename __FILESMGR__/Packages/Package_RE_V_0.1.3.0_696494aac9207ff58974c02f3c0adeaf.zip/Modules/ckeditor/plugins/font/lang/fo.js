﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'fo', {
	fontSize: {
		label: 'Skriftstødd',
		voiceLabel: 'Skriftstødd',
		panelTitle: 'Skriftstødd'
	},
	label: 'Skrift',
	panelTitle: 'Skrift',
	voiceLabel: 'Skrift'
} );
