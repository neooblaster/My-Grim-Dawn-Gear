﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'mn', {
	fontSize: {
		label: 'Хэмжээ',
		voiceLabel: 'Үсгийн хэмжээ',
		panelTitle: 'Үсгийн хэмжээ'
	},
	label: 'Үсгийн хэлбэр',
	panelTitle: 'Үгсийн хэлбэрийн нэр',
	voiceLabel: 'Үгсийн хэлбэр'
} );
