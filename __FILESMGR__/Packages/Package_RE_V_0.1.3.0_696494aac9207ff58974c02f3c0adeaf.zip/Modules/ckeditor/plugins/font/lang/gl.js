﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'gl', {
	fontSize: {
		label: 'Tamaño',
		voiceLabel: 'Tamaño da letra',
		panelTitle: 'Tamaño da letra'
	},
	label: 'Tipo de letra',
	panelTitle: 'Nome do tipo de letra',
	voiceLabel: 'Tipo de letra'
} );
