<?php


	function timestamp_to_date($date){
		
		return date("\T\h\\e l, F dS h:i A \P\a\\r\i\s \T\i\m\\e.", $date);
		
	}


?>