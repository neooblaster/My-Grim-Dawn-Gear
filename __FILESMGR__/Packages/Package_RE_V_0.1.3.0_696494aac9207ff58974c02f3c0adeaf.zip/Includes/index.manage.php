<?php
	
	/** > Inclure le script CKEDITOR **/
		$vars['INCLUDE_CKEDITOR'] = "true";


	/** > Chargement des jeux de donnée **/
		$vars['ARTICLES'] = load_articles();
		$vars['ITEMS_FAMILIES'] = load_items_families();
		$vars['ITEMS_QUALITIES'] = load_items_qualities();
		$vars['ITEMS_TYPES'] = load_items_types();
		$vars['ITEMS'] = load_items();

?>