function gear(){
	var self = this;
	
	self.slots = function(item){
		if(item !== undefined){
			var item_type = item.getAttribute('data-item-type');
		}
		
		return {
			drop: function(slot, e){
				var img = document.createElement('template');
					img.innerHTML = e.dataTransfer.getData('text/html');
					img = img.content.firstChild;
				
				var item_id = img.getAttribute('data-item-id');
				var item_attachment = img.getAttribute('data-attachment');
				
				slot.innerHTML = "";
				slot.classList.remove('quality_'+slot.getAttribute('data-quality'));
				slot.setAttribute('data-quality', img.getAttribute('data-quality'));
				slot.classList.add('quality_'+img.getAttribute('data-quality'));
				
				slot.appendChild(img);
				
				var slot_name;
				var slot_name_pattern = /^slot_/gi;
				
				for(var c = 0; c < slot.classList.length; c++){
					
					if(slot_name_pattern.test(slot.classList[c])){
						slot_name = slot.classList[c];
						break;
					}
				}
				
				var input_data = document.querySelector('#input_'+slot_name+'_'+item_attachment);
					input_data.value = item_id;
			},
			
			clear: function(){console.log('clear');},
			
			show: function(){
				var slots = document.querySelectorAll('.gear_panel_build_items_slot');
				
				for(var i = 0; i < slots.length; i++){
					var slot = slots[i];
					
					if(slot.getAttribute('hidden') === 'true'){
						continue;
					};
					
					var accept_item = slots[i].getAttribute('data-accept-item');
						accept_item = accept_item.split(',');
						
					var accepted = accept_item.lastIndexOf(item_type);
					
					if(accepted >= 0){
						slot.classList.add('droppable');
						
						slot.ondrop = function(evt){gear().slots().drop(this, evt);}.bind(slot);
						slot.ondragover = function(){return false;};
						slot.ondragenter = function(){self.slots().overlay(this).on();}.bind(slot);
						slot.ondragleave = function(){self.slots().overlay(this).off();}.bind(slot);
					} else {
						slot.classList.remove('droppable');
						
						slot.ondrop = "";
						slot.ondragover = "";
						slot.ondragenter = "";
						slot.ondragleave = "";
					} 
				}
			},
			
			hide: function(){
				var slots = document.querySelectorAll('.gear_panel_build_items_slot');
				
				for(var i = 0; i < slots.length; i++){
					var slot = slots[i];
					
					slot.classList.remove('droppable');
					slot.classList.remove('dropover');
					
					slot.ondrop = "";
					slot.ondragover = "";
					slot.ondragenter = "";
					slot.ondragleave = "";
				}
			},
			
			overlay: function(slot){
				return {
					on: function(){
						slot.classList.add('dropover');
					},
					
					off: function(){
						slot.classList.remove('dropover');
					}
				};
			}
		};
	};
	
	return self;
}

function dtest(ev){
	ev.preventDefault();console.log('test');
}