<?php

	const VERSION = '0.1.6.0';

?>