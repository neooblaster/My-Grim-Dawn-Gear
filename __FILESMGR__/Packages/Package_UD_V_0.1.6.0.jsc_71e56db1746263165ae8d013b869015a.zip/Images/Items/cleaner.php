<style>body {background: black;}</style>

<?php


	$scan = scandir('.');

foreach($scan as $k => $val){
	if(preg_match('#^tag#', $val)){
		echo "<img src='$val' />";
	}
}



?>