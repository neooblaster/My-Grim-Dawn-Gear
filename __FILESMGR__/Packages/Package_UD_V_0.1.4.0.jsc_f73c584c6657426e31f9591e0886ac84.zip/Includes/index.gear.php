<?php

	/** Indique que le volet des attributs est fermé (stats_fold) **/
	//$vars['STATS_FOLD'] = "stats_fold";

	/** Indique que le volet inventaire est fermé (inventory_fold) **/
	$vars['INVENTORY_FOLD'] = "inventory_fold";

?>